using UnityEngine;
using UnityEngine.Experimental.Rendering.Universal;
using UnityEngine.Rendering.Universal;

public class FlashlightController : MonoBehaviour
{
    public Light2D flashlight;
    public GameObject player;
    public float angleOffset = -90f;  // 根据手电筒 sprite 朝向调整
    public float rotateSpeed = 360f;  // 每秒旋转速度
    public InventoryGridUI inventoryUI;
    public SearchUIManager searchUI;
    public bool isOn = false;

    // Public property to check flashlight state
    public bool IsOn => isOn;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Confined;
        flashlight.enabled = isOn;

        if (inventoryUI == null)
        {
            inventoryUI = FindObjectOfType<InventoryGridUI>(true);
        }

        if (searchUI == null)
        {
            searchUI = FindObjectOfType<SearchUIManager>(true);
        }
    }

    void Update()
    {
        flashlight.transform.position = player.transform.position; // 始终跟随玩家位置

        // F 键开关手电筒
        if (Input.GetKeyDown(KeyCode.F))
        {
            isOn = !isOn;
            flashlight.enabled = isOn;
        }

        if (isOn && !IsUIBlockingRotation())
        {
            RotateTowardsMouse();
        }
    }

    bool IsUIBlockingRotation()
    {
        bool inventoryOpen = inventoryUI != null && inventoryUI.gameObject.activeInHierarchy;
        bool searchOpen = searchUI != null && searchUI.IsPanelOpen();
        return inventoryOpen || searchOpen;
    }

    void RotateTowardsMouse()
    {
        // 鼠标屏幕坐标 -> 世界坐标
        Vector3 mousePos = Input.mousePosition;
        mousePos.z = Mathf.Abs(Camera.main.transform.position.z - flashlight.transform.position.z);
        Vector3 worldMouse = Camera.main.ScreenToWorldPoint(mousePos);

        // 计算目标角度
        Vector3 direction = worldMouse - flashlight.transform.position;
        float targetAngle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg + angleOffset;

        // 当前角度
        float currentAngle = flashlight.transform.eulerAngles.z;

        // 平滑旋转到目标角度
        float newAngle = Mathf.MoveTowardsAngle(currentAngle, targetAngle, rotateSpeed * Time.deltaTime);

        flashlight.transform.rotation = Quaternion.Euler(0, 0, newAngle);
    }
}
