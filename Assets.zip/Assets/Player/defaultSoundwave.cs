using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
public class PlayerSoundWave : MonoBehaviour
{
    [Header("Sound Wave Settings")]
    public ToggleAndGlitchPostProcessing Toggle;
    public float interval = 10f;       // ÿ�������뷢��һ��
    public float maxRadius = 5f;       // Բ�����뾶
    public float expansionSpeed = 2f;  // Բ�����ٶ�
    public int segments = 100;         // Բ�߶���

    [Header("Player State")]
    public bool IsSoundMode;   // ����Ƿ�������ģʽ

    private LineRenderer lineRenderer;
    private float timer = 0f;
    private bool isExpanding = false;
    private float currentRadius = 0f;
    private Vector3 soundPosition;
    private bool newSound = false;

    void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.positionCount = segments + 1;
        lineRenderer.useWorldSpace = true;
        lineRenderer.enabled = false;

        LineRenderer lr = GetComponent<LineRenderer>();
        lr.sortingLayerName = "Foreground"; // ��Ҫ���� Project Settings -> Tags & Layers -> Sorting Layers ����
        lr.sortingOrder = 500; // ��ֵԽ��Խ��ǰ
    }

    void Update()
    {
        IsSoundMode = Toggle.ReturnMode();
        
        if (IsSoundMode)
        {
            timer += Time.deltaTime;
        }

        if (!isExpanding && timer >= interval && IsSoundMode)
        {
            EmitSoundWave();
            timer = 0f;
        }

        if (isExpanding)
        {
            currentRadius += expansionSpeed * Time.deltaTime;
            DrawCircle(currentRadius);

            if (currentRadius >= maxRadius)
            {
                isExpanding = false;
                lineRenderer.enabled = false;
            }
        }
    }

    void EmitSoundWave()
    {
        Debug.Log("first emitted");
        soundPosition = transform.position;
        currentRadius = 0f;
        isExpanding = true;
        newSound = true;
        lineRenderer.enabled = true;
    }

    void DrawCircle(float radius)
    {
        for (int i = 0; i <= segments; i++)
        {
            float angle = i * 2f * Mathf.PI / segments;
            float x = Mathf.Cos(angle) * radius;
            float y = Mathf.Sin(angle) * radius;
            lineRenderer.SetPosition(i, new Vector3(x, y, 0) + soundPosition);
        }
    }

    /// <summary>
    /// ����AI���ô˷�������Ƿ���������
    /// </summary>
    public bool HasNewSound()
    {
        if (newSound)
        {
            newSound = false;
            return true;
        }
        return false;
    }

    /// <summary>
    /// �����ȡ����λ��
    /// </summary>
    public Vector3 GetSoundPosition()
    {
        return soundPosition;
    }
}
