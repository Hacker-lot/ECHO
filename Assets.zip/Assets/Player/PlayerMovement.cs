using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    // --- Movement Variables ---
    public float moveSpeed = 5f;
    [Header("Inventory Speed Modifier")]
    [Range(0f, 1f)]
    [Tooltip("Movement speed multiplier when inventory is open (0 = stop, 1 = normal speed)")]
    public float inventoryOpenSpeedMultiplier = 0.5f;
    private Rigidbody2D rb;
    private Vector2 movement;

    [Header("Inventory and Looting Variables")]
    private Inventory playerInventory;
    public InventoryGridUI inventoryUI;
    private SearchUIManager searchUI;
    public float searchRange;
    private Lootable currentLootable;

    // --- Visual/Animation Variables ---
    [Header("Visual/Animation")]
    public Vector3 defaultScale = new Vector3(1, 1, 1);
    private Animator animator;
    private readonly int speedHash = Animator.StringToHash("Speed");

    // NEW: Variable to track the last non-zero movement direction for rotation
    private Vector2 lastMovement = Vector2.right; // Default to facing right
    private const float SpriteOffsetAngle = -90f;

    void Start()
    {
        // 1. Get Components
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();

        // 2. Set Initial Sprite Scale and Rotation
        transform.rotation = Quaternion.identity;
        transform.localScale = defaultScale;

        // 3. Get the Inventory component
        playerInventory = GetComponent<Inventory>();
        if (playerInventory == null)
        {
            Debug.LogError("PlayerMovement requires an Inventory component attached to the same GameObject.");
        }

        // 4. Find the UI managers
        searchUI = FindObjectOfType<SearchUIManager>(true);
   
        if (animator == null) Debug.LogError("PlayerMovement requires an Animator component.");
        if (inventoryUI == null) Debug.LogWarning("InventoryGridUI not found.");
        if (searchUI == null) Debug.LogWarning("SearchUIManager not found.");
    }

    void Update()
    {
        // --- Input Handling ---

        // 1. Get movement input
        movement = new Vector2(
            Input.GetAxisRaw("Horizontal"),
            Input.GetAxisRaw("Vertical")
        ).normalized;

        // 2. Direction Update (uses rotation) and Animation Update
        UpdateSpriteDirection(); // <-- UPDATED function call
        UpdateAnimations();

        CheckNearbyLootables();

        // 3. Check lootable interaction (Loot Key 'Q')
        if (Input.GetKeyDown(KeyCode.E) && currentLootable != null && searchUI != null)
        {
            if (!searchUI.IsSearching())
            {
                // ��ʼ����
                searchUI.StartSearch(currentLootable);
                searchUI.ShowHint(false);
                // Auto-open inventory when starting search
                if (inventoryUI != null && !inventoryUI.IsOpen())
                {
                    inventoryUI.ShowInventory();
                }
            }
        }

        // 4. Inventory Toggle (B key)
        if (Input.GetKeyDown(KeyCode.B) && inventoryUI != null && !searchUI.searchPanel.activeSelf)
        {
            inventoryUI.ToggleInventory();
        }
    }

    /// <summary>
    /// Handles movement physics in FixedUpdate.
    /// </summary>
    void FixedUpdate()
    {
        // Calculate effective speed based on inventory state
        float effectiveSpeed = moveSpeed;
        if (inventoryUI != null && inventoryUI.IsOpen())
        {
            effectiveSpeed *= inventoryOpenSpeedMultiplier;
        }

        rb.MovePosition(rb.position + movement * effectiveSpeed * Time.fixedDeltaTime);
    }

    /// <summary>
    /// Rotates the sprite to face the direction of movement.
    /// </summary>
    void UpdateSpriteDirection()
    {
        if (movement != Vector2.zero)
        {
            // Update the last movement direction when the player is moving
            lastMovement = movement;
        }

        // 1. Calculate the raw angle based on the vector
        float angle = Mathf.Atan2(lastMovement.y, lastMovement.x) * Mathf.Rad2Deg;

        // 2. Adjust for the sprite's default facing direction.
        // If the sprite is drawn facing RIGHT, and 'W' (up) should be 0 rotation, 
        // we need to rotate it back by 90 degrees.
        angle -= SpriteOffsetAngle;

        // 3. Apply the rotation around the Z-axis
        transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));

        // Ensure the scale remains the default, as rotation handles direction
        transform.localScale = defaultScale;
    }

    /// <summary>
    /// Calculates speed and sends it to the Animator for Idle/Walk transitions.
    /// </summary>
    void UpdateAnimations()
    {
        if (animator == null) return;

        // Use the magnitude of the input vector (0 when idle, 1 when moving)
        float currentSpeed = movement.magnitude;

        animator.SetFloat(speedHash, currentSpeed);
    }

    /// <summary>
    /// Checks for and interacts with a nearby Lootable object.
    /// </summary>
    private void CheckNearbyLootables()
    {
        Lootable closest = null;
        float minDist = float.MaxValue;

        foreach (var l in FindObjectsOfType<Lootable>())
        {
            float d = Vector2.Distance(transform.position, l.transform.position);
            if (d < minDist && d <= searchRange)
            {
                minDist = d;
                closest = l;
            }
        }

        // �뿪�� Lootable
        if (closest != currentLootable)
        {
            if (currentLootable != null)
            {
                searchUI.CancelSearch(); // �ر����
                inventoryUI.HideInventory();
                // Note: We don't auto-close inventory when leaving lootable
            }
            currentLootable = closest;
        }

        // ��ʾ��ʾ
        if (currentLootable != null)
            searchUI.ShowHint(true);
        else
            searchUI.ShowHint(false);
    }




    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, searchRange);
    }
}