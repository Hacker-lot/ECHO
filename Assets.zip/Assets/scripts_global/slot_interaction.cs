using UnityEngine;
using UnityEngine.EventSystems;

// This component must be added to the InventorySlot prefab used for the search UI.
public class SearchSlotInteraction : MonoBehaviour, IPointerClickHandler
{
    // The InventorySlot visual component attached to the same GameObject
    private InventorySlot inventorySlot;
    private Inventory playerInventory;
    private SearchUIManager searchUI;

    // The actual item data for transfer (passed from SearchUIManager)
    public Inventory.InventorySlotData LootData { get; set; }

    // Index of this slot in the *UI* display, used to tell the UIManager which slot was emptied.
    [HideInInspector] public int slotIndex;

    void Start()
    {
        // Get required components/references
        inventorySlot = GetComponent<InventorySlot>();
        playerInventory = FindObjectOfType<Inventory>();
        searchUI = FindObjectOfType<SearchUIManager>();

        if (inventorySlot == null || playerInventory == null || searchUI == null)
        {
            Debug.LogError("SearchSlotInteraction failed to find required components.");
        }
    }

    /// <summary>
    /// Handles the mouse click event on the loot slot.
    /// </summary>
    public void OnPointerClick(PointerEventData eventData)
    {
        // Check if the slot actually contains an item
        if (inventorySlot.currentItem != null)
        {
            // Check if inventory panel is also open - if so, transfer item to inventory
            InventoryGridUI inventoryUI = FindObjectOfType<InventoryGridUI>();
            if (inventoryUI != null && inventoryUI.IsOpen())
            {
                // Both panels open - transfer from search panel to inventory
                bool success = playerInventory.AddItem(inventorySlot.currentItem, inventorySlot.currentCount);

                if (success)
                {
                    // Remove from search panel
                    searchUI.RemoveItemFromSearchPanel(slotIndex);
                }
            }
            else
            {
                // Only search panel open - normal collection behavior
                // 1. Try to add the item to the player's inventory
                bool success = playerInventory.AddItem(inventorySlot.currentItem, inventorySlot.currentCount);

                if (success)
                {
                    // 2. If successful, clear the item data (so the slot is now empty)
                    // This clears the data in the SearchUIManager's internal list via the shared LootData reference.
                    if (LootData != null)
                    {
                        LootData.item = null;
                        LootData.count = 0;
                    }

                    // 3. Inform the UIManager that this slot was collected.
                    searchUI.ItemCollected(slotIndex);
                }
            }
        }
    }
}