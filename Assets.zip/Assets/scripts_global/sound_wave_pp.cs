using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class DynamicPostProcessing : MonoBehaviour
{
    public Volume globalVolume;

    private ChromaticAberration chromaticAberration;
    private Vignette vignette;
    private LensDistortion lensDistortion;

    public float maxChromaticIntensity = 1f;
    public float nauseaSpeed = 2f;

    public float lensMaxIntensity = 0.3f;
    public float lensFrequency = 1.5f;
    public float lensScaleMin = 0.95f;
    public float lensScaleMax = 1.05f;
    public float centerMoveAmplitude = 0.05f; // �����ƶ�����

    void Start()
    {
        if (globalVolume.profile.TryGet(out chromaticAberration) == false)
            Debug.LogError("Could not find Chromatic Aberration in Volume Profile.");

        if (globalVolume.profile.TryGet(out vignette) == false)
            Debug.LogError("Could not find Vignette in Volume Profile.");

        if (globalVolume.profile.TryGet(out lensDistortion) == false)
            Debug.LogError("Could not find Lens Distortion in Volume Profile.");

        chromaticAberration.intensity.overrideState = true;
        vignette.intensity.overrideState = true;
        lensDistortion.intensity.overrideState = true;
        lensDistortion.scale.overrideState = true;
        lensDistortion.center.overrideState = true; // ���� center ���޸�
    }

    void Update()
    {
        AnimateChromaticAberration();
        SetVignetteIntensity(0.5f + Mathf.Sin(Time.time * 0.5f) * 0.2f);
        AnimateLensDistortion();
    }

    void AnimateChromaticAberration()
    {
        if (chromaticAberration != null)
        {
            float sinWave = Mathf.Sin(Time.time * nauseaSpeed);
            chromaticAberration.intensity.value = (sinWave + 1f) / 2f * maxChromaticIntensity;
        }
    }

    void SetVignetteIntensity(float newIntensity)
    {
        if (vignette != null)
        {
            vignette.intensity.value = Mathf.Clamp01(newIntensity);
        }
    }

    void AnimateLensDistortion()
    {
        if (lensDistortion != null)
        {
            // ����ǿ��
            float intensity = Mathf.Sin(Time.time * lensFrequency) * lensMaxIntensity;
            lensDistortion.intensity.value = intensity;

            // ����
            float scale = Mathf.Lerp(lensScaleMin, lensScaleMax, (Mathf.Sin(Time.time * lensFrequency) + 1f) / 2f);
            lensDistortion.scale.value = scale;

            // ���Ķ�̬�ƶ������Ҳ���
            float centerX = 0.5f + Mathf.Sin(Time.time * lensFrequency * 0.7f) * centerMoveAmplitude;
            float centerY = 0.5f + Mathf.Cos(Time.time * lensFrequency * 0.9f) * centerMoveAmplitude;
            lensDistortion.center.value = new Vector2(centerX, centerY);
        }
    }
}
