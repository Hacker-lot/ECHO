using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Linq;
using TMPro; // For conversion
using Economy;

public class SearchUIManager : MonoBehaviour
{
    [Header("UI Elements")]
    public GameObject searchPanel;
    public Slider progressBar;
    public Transform lootSlotsParent;
    public GameObject searchHint;
    public GameObject pickHint;

    private InventorySlot[] lootSlots;
    private Image searchPanelBackground; // Reference to the background image

    [Header("Internal State")]
    private Lootable currentLootable;
    private Inventory playerInventory;
    private float searchTimer;
    private float maxSearchTime;
    private bool isSearching = false;

    // NEW: List to hold the actual items rolled upon completion
    private List<Inventory.InventorySlotData> rolledLoot = new List<Inventory.InventorySlotData>();

    void Start()
    {
        // Initial state setup (keeping user's original activation logic)
        bool wasActive = gameObject.activeSelf;
        if (!wasActive)
        {
            gameObject.SetActive(true);
        }

        // Get slots from the crate's slotsParent
        lootSlots = lootSlotsParent.GetComponentsInChildren<InventorySlot>();
        playerInventory = FindObjectOfType<Inventory>();

        // Find and configure the search panel background to not block raycasts
        if (searchPanel != null)
        {
            searchPanelBackground = searchPanel.GetComponent<Image>();
            if (searchPanelBackground != null)
            {
                searchPanelBackground.raycastTarget = false; // Allow clicks to pass through to inventory slots
            }
        }

        // Safety check on initialization (Check for null slots immediately)
        for (int i = 0; i < lootSlots.Length; i++)
        {
            if (lootSlots[i] == null)
            {
                Debug.LogError($"SearchUIManager: Slot at index {i} is NULL. Please check the children of the {lootSlotsParent.name} in the Inspector.");
                // We could use a List instead of an array and remove the null entry, but 
                // for simplicity, we keep the array and rely on later checks.
            }
            else
            {
                // Assign the SearchSlotInteraction script to all *valid* loot slots
                SearchSlotInteraction interaction = lootSlots[i].gameObject.AddComponent<SearchSlotInteraction>();
                // Pass the index for management
                interaction.slotIndex = lootSlots[i].transform.GetSiblingIndex();
                lootSlots[i].allowDrag = false;
                lootSlots[i].allowDrop = false;
            }
        }

        // 2. Return the panel to its default, hidden state
        if (wasActive)
        {
            gameObject.SetActive(false);
        }
    }

    void Update()
    {
        if (isSearching)
        {
            searchTimer += Time.deltaTime;
            progressBar.value = searchTimer / maxSearchTime;

            if (searchTimer >= maxSearchTime)
            {
                FinishSearch();
            }
        }
    }

    /// <summary>
    /// Called by PlayerController to begin the interaction.
    /// </summary>
    public void StartSearch(Lootable lootable)
    {
        currentLootable = lootable;

        if (currentLootable.HasGeneratedLoot())
        {
            // Already generated loot - show it immediately
            isSearching = false;
            searchTimer = 0f;
            ShowPanel();
            if (progressBar != null) progressBar.value = 1f;
            rolledLoot = currentLootable.GetCurrentLoot();
            DisplayRolledLoot();
            return;
        }

        // Make sure CalculateSearchDuration() is not null before using it
        if (currentLootable.CalculateSearchDuration() <= 0)
        {
            maxSearchTime = 1f; // Default to 1 second if value is bad
        }
        else
        {
            maxSearchTime = currentLootable.CalculateSearchDuration();
        }

        searchTimer = 0f;
        isSearching = true;
        currentLootable.GetCurrentLoot().Clear();
        rolledLoot = currentLootable.GetCurrentLoot();

        // Show UI 
        ShowPanel();
        if (progressBar != null) progressBar.value = 0f;

        // NEW: HIDE items while searching. Clear all slots.
        ClearLootDisplay(); // <-- This is where the error occurred
    }

    private void FinishSearch()
    {
        isSearching = false;

        // *** FIX HERE: Add null check for currentLootable ***
        if (currentLootable == null)
        {
            Debug.LogWarning("Search finished, but currentLootable reference is missing or was destroyed.");
            HidePanel(); // Close panel safely
            return;
        }

        // 1. Roll the loot from the Lootable object (cached per crate)
        rolledLoot = currentLootable.GenerateLoot();

        // 2. Display the rolled loot to the user for one-by-one collection
        if (progressBar != null) progressBar.value = 1f;
        DisplayRolledLoot();
    }

    // NEW: Method to display the actual rolled loot
    private void DisplayRolledLoot()
    {
        List<Inventory.InventorySlotData> lootToDisplay = rolledLoot ?? currentLootable?.GetCurrentLoot();

        for (int i = 0; i < lootSlots.Length; i++)
        {
            // *** FIX HERE: Check if the slot itself is null before using it ***
            if (lootSlots[i] == null) continue;

            if (lootToDisplay != null && i < lootToDisplay.Count)
            {
                Inventory.InventorySlotData loot = lootToDisplay[i];
                lootSlots[i].UpdateSlot(loot.item, loot.count);

                SearchSlotInteraction interaction = lootSlots[i].GetComponent<SearchSlotInteraction>();

                if (interaction != null)
                {
                    interaction.LootData = loot;
                }
                else
                {
                    Debug.LogError($"SearchSlotInteraction missing on loot slot {i}. Check your setup in Start().");
                }
            }
            else
            {
                lootSlots[i].ClearSlot();
            }
        }
    }

    // NEW: Method to clear the loot slots display
    private void ClearLootDisplay()
    {
        for (int i = 0; i < lootSlots.Length; i++)
        {
            // *** FIX HERE (Line 134 in your error trace): Check if the slot itself is null before using it ***
            if (lootSlots[i] != null)
            {
                lootSlots[i].ClearSlot();
            }
        }
    }

    /// <summary>
    /// Called by a SearchSlotInteraction when an item is clicked and successfully transferred.
    /// </summary>
    public void ItemCollected(int slotIndex)
    {
        // Check if the array access is safe and the element is not null
        if (slotIndex >= 0 && slotIndex < lootSlots.Length && lootSlots[slotIndex] != null)
        {
            // 1. Clear the UI slot visually
            lootSlots[slotIndex].ClearSlot();

            // 2. Check if all slots are now empty
            // We use Any() combined with a null check to check for remaining items.
            bool allEmpty = !lootSlots.Any(slot => slot != null && slot.currentItem != null);

            if (allEmpty)
            {
                Debug.Log("Looting finished. Closing search panel.");
                HidePanel();
                ShowHint(false);

                // Mark the lootable as depleted
                if (currentLootable != null)
                {
                    currentLootable.MarkDepleted();
                    currentLootable = null;
                }
            }
        }
    }

    /// <summary>
    /// Shows the search panel.
    /// </summary>
    public void ShowPanel()
    {
        if (searchPanel != null && !searchPanel.activeSelf)
        {
            searchPanel.SetActive(true);
        }
    }

    /// <summary>
    /// Hides the search panel and resets search state if needed.
    /// </summary>
    public void HidePanel()
    {
        if (searchPanel != null && searchPanel.activeSelf)
        {
            searchPanel.SetActive(false);
        }

        // If we're in the middle of searching, cancel it
        if (isSearching)
        {
            isSearching = false;
            searchTimer = 0f;
            if (progressBar != null) progressBar.value = 0f;
        }
    }

    /// <summary>
    /// Cancels an active search and closes the panel.
    /// </summary>
    public void CancelSearch()
    {
        if (isSearching)
        {
            isSearching = false;
            searchTimer = 0f;
            if (progressBar != null) progressBar.value = 0f;
        }
        HidePanel();
        currentLootable = null;
    }

    /// <summary>
    /// Returns whether the search panel is currently open.
    /// </summary>
    public bool IsPanelOpen()
    {
        return searchPanel != null && searchPanel.activeSelf;
    }

    /// <summary>
    /// Returns whether a search is currently in progress.
    /// </summary>
    public bool IsSearching()
    {
        return isSearching;
    }

    /// <summary>
    /// Shows or hides the search hint.
    /// </summary>
    public void ShowHint(bool show)
    {
        if (searchHint != null)
        {
            searchHint.SetActive(show);
        }
    }

    /// <summary>
    /// Shows or hides the pick hint.
    /// </summary>
    public void ShowHint_pick(bool show)
    {
        if (pickHint != null)
        {
            pickHint.SetActive(show);
        }
    }

    /// <summary>
    /// Adds an item to the search panel if there's an empty slot.
    /// Returns true if successful, false if no space available.
    /// </summary>
    public bool AddItemToSearchPanel(Item item, int count = 1)
    {
        if (item == null || count <= 0) return false;
        if (!IsPanelOpen()) return false;

        // Ensure rolledLoot list exists and has enough slots
        if (rolledLoot == null)
        {
            rolledLoot = new List<Inventory.InventorySlotData>();
        }

        // Find first empty slot in rolledLoot
        for (int i = 0; i < lootSlots.Length; i++)
        {
            // Extend rolledLoot list if needed
            while (rolledLoot.Count <= i)
            {
                rolledLoot.Add(new Inventory.InventorySlotData { item = null, count = 0 });
            }

            if (rolledLoot[i].item == null)
            {
                // Found empty slot - add item
                rolledLoot[i].item = item;
                rolledLoot[i].count = count;

                // Update UI
                lootSlots[i].UpdateSlot(item, count);

                // Update SearchSlotInteraction
                SearchSlotInteraction interaction = lootSlots[i].GetComponent<SearchSlotInteraction>();
                if (interaction != null)
                {
                    interaction.LootData = rolledLoot[i];
                }

                // Update Lootable's currentLoot if it exists
                if (currentLootable != null)
                {
                    List<Inventory.InventorySlotData> currentLoot = currentLootable.GetCurrentLoot();
                    while (currentLoot.Count <= i)
                    {
                        currentLoot.Add(new Inventory.InventorySlotData { item = null, count = 0 });
                    }
                    currentLoot[i] = rolledLoot[i];
                }

                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Removes an item from the search panel at the specified slot index.
    /// </summary>
    public void RemoveItemFromSearchPanel(int slotIndex)
    {
        if (slotIndex < 0 || slotIndex >= lootSlots.Length) return;
        if (rolledLoot == null || slotIndex >= rolledLoot.Count) return;

        // Clear the slot
        rolledLoot[slotIndex].item = null;
        rolledLoot[slotIndex].count = 0;

        // Update UI
        if (lootSlots[slotIndex] != null)
        {
            lootSlots[slotIndex].ClearSlot();
        }

        // Update Lootable's currentLoot if it exists
        if (currentLootable != null)
        {
            List<Inventory.InventorySlotData> currentLoot = currentLootable.GetCurrentLoot();
            if (slotIndex < currentLoot.Count)
            {
                currentLoot[slotIndex].item = null;
                currentLoot[slotIndex].count = 0;
            }
        }

        // Check if all slots are empty and close panel if needed
        bool allEmpty = !lootSlots.Any(slot => slot != null && slot.currentItem != null);
        if (allEmpty && !isSearching)
        {
            // Don't auto-close if there are items that were originally in the crate
            // Only close if this was a manually added item and all are removed
        }
    }

}