using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using Economy;

public class Inventory : MonoBehaviour
{
    // NEW: Data structure to hold an item and its count in a specific slot.
    [System.Serializable]
    public class InventorySlotData
    {
        public Item item;
        public int count;
    }

    [Header("Backpack Settings")]
    public int maxCapacity = 20;

    // REPLACED DICTIONARY: This List now represents the fixed grid slots.
    public List<InventorySlotData> slots = new List<InventorySlotData>();

    // Reference to the UI Manager to update the visual display (Now assigned in Inspector)
    public InventoryGridUI inventoryUI;

    void Start()
    {
        // 1. Initialize all slots as empty at the start
        for (int i = 0; i < maxCapacity; i++)
        {
            slots.Add(new InventorySlotData { item = null, count = 0 });
        }

        // 2. Check if the UI reference is set (It must now be assigned in the Inspector)
        if (inventoryUI == null)
        {
            // Note: If you want the UI to be found automatically, change 'public InventoryGridUI inventoryUI;' back to private
            // and uncomment the FindObjectOfType line.
            // inventoryUI = FindObjectOfType<InventoryGridUI>(); 
            Debug.LogWarning("Inventory: inventoryUI reference is null. Please assign InventoryGridUI in the Inspector.");
        }
    }

    /// <summary>
    /// Attempts to add an item to the inventory. Items no longer stack; each occupies a slot.
    /// </summary>
    public bool AddItem(Item item, int count = 1)
    {
        if (item == null || count <= 0) return false;

        int itemsToAdd = count;

        // Iterate through slots, placing a single instance (count = 1) of the item in each empty slot.
        for (int i = 0; i < slots.Count && itemsToAdd > 0; i++)
        {
            if (slots[i].item == null)
            {
                slots[i].item = item;
                slots[i].count = 1; // Each slot holds only one instance of the item
                itemsToAdd--;
            }
        }

        if (inventoryUI != null) inventoryUI.UpdateDisplay();

        if (itemsToAdd > 0)
        {
            Debug.Log("Inventory is full! Could not add all copies of " + item.itemName);
            return false;
        }

        Debug.Log($"Successfully added {count - itemsToAdd} copies of {item.itemName} (one per slot).");
        return true;
    }

    /// <summary>
    /// Attempts to remove an item from a specific slot.
    /// </summary>
    public void RemoveItem(int slotIndex, int count = 1)
    {
        if (slotIndex < 0 || slotIndex >= slots.Count) return;
        InventorySlotData slot = slots[slotIndex];

        if (slot.item == null) return;

        slot.count -= count;
        if (slot.count <= 0)
        {
            slot.item = null;
            slot.count = 0;
            Debug.Log($"Removed item from slot {slotIndex}.");
        }

        if (inventoryUI != null)
        {
            inventoryUI.UpdateDisplay();
        }
    }

    /// <summary>
    /// Handles the core data swap between two slot indices (used for drag-and-drop).
    /// </summary>
    public void SwapSlots(int indexA, int indexB)
    {
        if (indexA < 0 || indexA >= slots.Count || indexB < 0 || indexB >= slots.Count)
        {
            Debug.LogError("Invalid slot index provided for swap.");
            return;
        }

        // Perform the swap
        InventorySlotData temp = slots[indexA];
        slots[indexA] = slots[indexB];
        slots[indexB] = temp;
    }

    /// <summary>
    /// Clears all items from the inventory (used by respawn/death logic).
    /// </summary>
    public void ClearAllItems()
    {
        for (int i = 0; i < slots.Count; i++)
        {
            slots[i].item = null;
            slots[i].count = 0;
        }

        if (inventoryUI != null)
        {
            inventoryUI.UpdateDisplay();
        }
    }
}