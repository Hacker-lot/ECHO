// PixelizeFeature.cs
using UnityEngine;
using UnityEngine.Rendering.Universal;

public class PixelizeFeature : ScriptableRendererFeature
{
    [System.Serializable]
    public class Settings
    {
        // Expose settings in the Inspector
        public int pixelHeight = 90;
    }

    public Settings settings = new Settings();
    private PixelizePass pixelizePass;

    public override void Create()
    {
        // We don't need a special shader (Material) for simple Blit, 
        // but if we did, it would be initialized here.
        pixelizePass = new PixelizePass(null);
    }

    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        // Configure the pass with the camera's current target and the desired resolution
        pixelizePass.Setup(renderer.cameraColorTargetHandle, settings.pixelHeight);
        renderer.EnqueuePass(pixelizePass);
    }
}