﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

namespace Economy
{
    public class ShopManager : MonoBehaviour
    {
        [Header("UI References")]
        [SerializeField] private GameObject shopPanel;
        [SerializeField] private TextMeshProUGUI currencyText;
        [SerializeField] private Transform itemsContainer;

        [Header("Shop Items")]
        [SerializeField] private List<Item> shopItems = new List<Item>();

        [Header("Dynamic Item UI Settings (REQUIRED)")]
        [SerializeField] private TMP_FontAsset defaultFontAsset;

        // 🟢 NEW: Reference to the player's Inventory script
        private Inventory playerInventory;

        private void Start()
        {
            if (shopPanel != null)
                shopPanel.SetActive(false);

            // 🟢 NEW: Find the player inventory object
            playerInventory = FindObjectOfType<Inventory>();
            if (playerInventory == null)
            {
                Debug.LogError("ShopManager cannot find Inventory script. Make sure it's in the scene.");
            }

            // Subscribe to currency changes
            if (CurrencyManager.Instance != null)
            {
                CurrencyManager.Instance.OnMoneyChanged += UpdateCurrencyDisplay;
                UpdateCurrencyDisplay(CurrencyManager.Instance.CurrentMoney);
            }

            PopulateShop();
        }

        private void OnDestroy()
        {
            if (CurrencyManager.Instance != null)
            {
                CurrencyManager.Instance.OnMoneyChanged -= UpdateCurrencyDisplay;
            }
        }

        private void Update()
        {
            // Allows closing the panel with the ESCAPE key
            if (shopPanel.activeSelf && Input.GetKeyDown(KeyCode.Escape))
            {
                CloseShop();
            }
        }

        // 🟢 NEW HELPER: Used by InventSlot.cs to check if the Sell action should be active
        public bool IsShopOpen()
        {
            if (shopPanel == null) return false;
            return shopPanel.activeSelf;
        }

        public void OpenShop()
        {
            if (shopPanel != null)
            {
                shopPanel.SetActive(true);
                Time.timeScale = 0f; // Pause game
                if (CurrencyManager.Instance != null)
                {
                    UpdateCurrencyDisplay(CurrencyManager.Instance.CurrentMoney);
                }
            }
        }

        public void CloseShop()
        {
            if (shopPanel != null)
            {
                shopPanel.SetActive(false);
                Time.timeScale = 1f; // Resume game
            }
        }

        private void UpdateCurrencyDisplay(int amount)
        {
            if (currencyText != null)
            {
                currencyText.text = $"${amount}";
            }
        }

        private void PopulateShop()
        {
            if (itemsContainer == null || defaultFontAsset == null)
            {
                Debug.LogError("itemsContainer or defaultFontAsset is not assigned. Cannot populate shop dynamically.");
                return;
            }

            foreach (Transform child in itemsContainer)
            {
                Destroy(child.gameObject);
            }

            foreach (Item item in shopItems)
            {
                GameObject itemButtonGO = new GameObject($"ShopItem_{item.itemName}", typeof(RectTransform));
                itemButtonGO.transform.SetParent(itemsContainer, false);

                Button button = itemButtonGO.AddComponent<Button>();
                Image buttonImage = itemButtonGO.AddComponent<Image>();
                buttonImage.sprite = item.icon;
                button.targetGraphic = buttonImage;

                GameObject textGO = new GameObject("ItemText", typeof(RectTransform));
                textGO.transform.SetParent(itemButtonGO.transform, false);

                RectTransform textRect = textGO.GetComponent<RectTransform>();
                textRect.anchorMin = new Vector2(0, 0);
                textRect.anchorMax = new Vector2(1, 1);
                textRect.sizeDelta = new Vector2(0, 0);

                TextMeshProUGUI itemText = textGO.AddComponent<TextMeshProUGUI>();
                itemText.font = defaultFontAsset;
                itemText.text = $"{item.itemName}\n<size=70%>(${item.price})</size>";
                itemText.alignment = TextAlignmentOptions.Center;
                itemText.fontSize = 12;
                itemText.color = Color.black;

                Item currentItem = item;
                button.onClick.AddListener(() => BuyItem(currentItem));
            }
        }

        // ⚠️ MODIFIED: Integrated with your Inventory.cs
        private void BuyItem(Item item)
        {
            if (CurrencyManager.Instance == null || playerInventory == null) return;

            if (CurrencyManager.Instance.SpendMoney(item.price))
            {
                // 🟢 FIX 2: Add item to player backpack (Inventory.cs)
                // Your Inventory.cs AddItem method takes an item and an optional count (defaults to 1)
                if (playerInventory.AddItem(item, 1))
                {
                    Debug.Log($"Purchased: {item.itemName} and added to inventory.");

                    // 🟢 FIX 1: Remove the item from the shop's list (limited stock example)
                    RemoveItemFromShop(item);
                }
                else
                {
                    Debug.Log($"Inventory full! Cannot purchase {item.itemName}. Refunding money.");
                    // Refund the money if the inventory is full
                    CurrencyManager.Instance.AddMoney(item.price);
                }
            }
            else
            {
                Debug.Log($"Cannot afford {item.itemName}");
            }
        }

        // 🟢 NEW HELPER: Calculates the amount of money the player gets for selling an item.
        private int GetSellPrice(Item item)
        {
            // Example policy: Items sell for 50% of their buy price.
            return item.price / 2;
        }

        // 🟢 NEW PUBLIC METHOD: Called by InventSlot.cs to sell an item.
        // It requires the slot index because that's how your Inventory.cs removes items.
        public bool SellItem(int slotIndex)
        {
            if (CurrencyManager.Instance == null || playerInventory == null) return false;

            // Check if the slot exists and has an item
            if (slotIndex < 0 || slotIndex >= playerInventory.slots.Count) return false;
            Inventory.InventorySlotData slot = playerInventory.slots[slotIndex];

            if (slot.item == null) return false;

            Item itemToSell = slot.item;
            int sellPrice = GetSellPrice(itemToSell);

            // 1. Remove the item from the player's inventory
            playerInventory.RemoveItem(slotIndex, 1);

            // 2. Add money to the player
            CurrencyManager.Instance.AddMoney(sellPrice);

            Debug.Log($"Sold: {itemToSell.itemName} from slot {slotIndex} for {sellPrice} money.");
            return true;
        }

        public void AddItemToShop(Item item)
        {
            if (!shopItems.Contains(item))
            {
                shopItems.Add(item);
                PopulateShop();
            }
        }

        public void RemoveItemFromShop(Item item)
        {
            if (shopItems.Contains(item))
            {
                shopItems.Remove(item);
                PopulateShop();
            }
        }
    }
}