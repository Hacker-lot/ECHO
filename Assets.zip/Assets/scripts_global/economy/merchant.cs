﻿using UnityEngine;
using TMPro;
using Economy; // Ensure this namespace is correctly included if your ShopManager/Inventory are in it

namespace Economy
{
    public class Merchant : MonoBehaviour
    {
        [Header("Interaction Settings")]
        [SerializeField] private float interactionRange = 3f;
        // 🟢 FIXED: Changed interaction key from E to Q
        [SerializeField] private KeyCode interactionKey = KeyCode.Q;

        [Header("UI References")]
        [SerializeField] private GameObject interactionPrompt;
        [SerializeField] private TextMeshProUGUI promptText;

        [Header("Shop Reference")]
        [SerializeField] private ShopManager shopManager;

        // 🟢 NEW: Reference to the Player's Inventory UI
        [Header("Inventory Reference (For Sell Mode)")]
        [SerializeField] private InventoryGridUI inventoryUI;

        private Transform player;
        private bool playerInRange = false;

        private void Start()
        {
            if (interactionPrompt != null)
                interactionPrompt.SetActive(false);

            // Find player by tag
            GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
            if (playerObj != null)
                player = playerObj.transform;

            // Update prompt text with the new key
            if (promptText != null)
                promptText.text = $"Press {interactionKey} to Shop";

            // Find shop manager if not assigned
            if (shopManager == null)
                shopManager = FindObjectOfType<ShopManager>();

            // 🟢 NEW: Find inventory UI if not assigned
            if (inventoryUI == null)
                inventoryUI = FindObjectOfType<InventoryGridUI>();
        }

        private void Update()
        {
            CheckPlayerDistance();

            // Check if player is in range and presses the interaction key (Q)
            if (playerInRange && Input.GetKeyDown(interactionKey))
            {
                // Toggle the shop state
                if (shopManager != null && shopManager.IsShopOpen())
                {
                    CloseShop();
                }
                else
                {
                    OpenShop();
                }
            }
        }

        private void CheckPlayerDistance()
        {
            // Assuming the Player object has been found
            if (player == null) return;

            float distance = Vector3.Distance(transform.position, player.position);
            bool nowInRange = distance <= interactionRange;

            // Handle range change for prompt visibility
            if (nowInRange != playerInRange)
            {
                playerInRange = nowInRange;
                if (interactionPrompt != null)
                    interactionPrompt.SetActive(playerInRange);
            }

            // Optional: Auto-close the shop if player moves out of range while it's open
            if (!playerInRange && shopManager != null && shopManager.IsShopOpen())
            {
                CloseShop();
            }
        }

        // 🟢 MODIFIED: Opens the ShopManager and the Inventory UI
        private void OpenShop()
        {
            if (shopManager != null)
            {
                shopManager.OpenShop();
            }
            // 🟢 ACTION: Show the player's inventory UI so they can sell
            if (inventoryUI != null)
            {
                inventoryUI.ShowInventory(); // Assumes this method exists in InventGridUI.cs
            }
            else
            {
                Debug.LogWarning("Inventory UI reference missing on Merchant. Cannot show player backpack for selling.");
            }
        }

        // 🟢 MODIFIED: Closes the ShopManager and the Inventory UI
        private void CloseShop()
        {
            if (shopManager != null)
            {
                shopManager.CloseShop();
            }
            // 🟢 ACTION: Hide the player's inventory UI when the shop closes
            if (inventoryUI != null)
            {
                inventoryUI.HideInventory(); // Assumes this method exists in InventGridUI.cs
            }

            // Re-show the interaction prompt if the player is still in range (for re-opening)
            if (playerInRange && interactionPrompt != null)
            {
                interactionPrompt.SetActive(true);
            }
        }

        private void OnDrawGizmosSelected()
        {
            // Visualize interaction range in editor
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, interactionRange);
        }

        // --- Trigger-based logic (Kept from original file) ---

        private void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                playerInRange = true;
                if (interactionPrompt != null)
                    interactionPrompt.SetActive(true);
            }
        }

        private void OnTriggerExit(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                playerInRange = false;
                if (interactionPrompt != null)
                    interactionPrompt.SetActive(false);

                // Automatically close shop when player leaves trigger zone
                CloseShop();
            }
        }

        // For 2D collisions
        private void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("Player"))
            {
                playerInRange = true;
                if (interactionPrompt != null)
                    interactionPrompt.SetActive(true);
            }
        }

        private void OnTriggerExit2D(Collider2D other)
        {
            if (other.CompareTag("Player"))
            {
                playerInRange = false;
                if (interactionPrompt != null)
                    interactionPrompt.SetActive(false);

                // Automatically close shop when player leaves trigger zone
                CloseShop();
            }
        }
    }
}