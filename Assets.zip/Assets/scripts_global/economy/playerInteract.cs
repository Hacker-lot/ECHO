using UnityEngine;

namespace Economy
{
    public class PlayerInteraction : MonoBehaviour
    {
        [SerializeField] private float interactionRange = 3f;
        [SerializeField] private KeyCode interactionKey = KeyCode.E;
        [SerializeField] private LayerMask interactableLayer;

        private Merchant currentMerchant;

        private void Update()
        {
            CheckForInteractables();

            if (Input.GetKeyDown(interactionKey) && currentMerchant != null)
            {
                // Merchant handles its own interaction through its Update method
                // This is an alternative approach if needed
            }
        }

        private void CheckForInteractables()
        {
            Collider[] colliders = Physics.OverlapSphere(transform.position, interactionRange, interactableLayer);

            Merchant nearestMerchant = null;
            float nearestDistance = float.MaxValue;

            foreach (Collider col in colliders)
            {
                Merchant merchant = col.GetComponent<Merchant>();
                if (merchant != null)
                {
                    float distance = Vector3.Distance(transform.position, col.transform.position);
                    if (distance < nearestDistance)
                    {
                        nearestDistance = distance;
                        nearestMerchant = merchant;
                    }
                }
            }

            currentMerchant = nearestMerchant;
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawWireSphere(transform.position, interactionRange);
        }
    }
}