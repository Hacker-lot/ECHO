using UnityEngine;
using System;

namespace Economy
{
    public class CurrencyManager : MonoBehaviour
    {
        public static CurrencyManager Instance { get; private set; }

        [SerializeField] private int startingMoney = 100;
        private int currentMoney;

        public event Action<int> OnMoneyChanged;

        public int CurrentMoney => currentMoney;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            currentMoney = startingMoney;
        }

        private void Start()
        {
            OnMoneyChanged?.Invoke(currentMoney);
        }

        public bool CanAfford(int amount)
        {
            return currentMoney >= amount;
        }

        public bool SpendMoney(int amount)
        {
            if (!CanAfford(amount))
            {
                Debug.Log("Not enough money!");
                return false;
            }

            currentMoney -= amount;
            OnMoneyChanged?.Invoke(currentMoney);
            Debug.Log($"Spent {amount} money. Remaining: {currentMoney}");
            return true;
        }

        public void AddMoney(int amount)
        {
            currentMoney += amount;
            OnMoneyChanged?.Invoke(currentMoney);
            Debug.Log($"Added {amount} money. Total: {currentMoney}");
        }

        public void SetMoney(int amount)
        {
            currentMoney = amount;
            OnMoneyChanged?.Invoke(currentMoney);
        }
    }
}