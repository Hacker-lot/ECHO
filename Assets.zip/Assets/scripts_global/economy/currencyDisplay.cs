using UnityEngine;
using TMPro;

namespace Economy
{
    public class CurrencyDisplay : MonoBehaviour
    {
        [SerializeField] private TextMeshProUGUI currencyText;
        [SerializeField] private string prefix = "$";
        [SerializeField] private string suffix = "";

        private void Start()
        {
            if (CurrencyManager.Instance != null)
            {
                CurrencyManager.Instance.OnMoneyChanged += UpdateDisplay;
                UpdateDisplay(CurrencyManager.Instance.CurrentMoney);
            }
        }

        private void OnDestroy()
        {
            if (CurrencyManager.Instance != null)
            {
                CurrencyManager.Instance.OnMoneyChanged -= UpdateDisplay;
            }
        }

        private void UpdateDisplay(int amount)
        {
            if (currencyText != null)
            {
                currencyText.text = $"{prefix}{amount}{suffix}";
            }
        }
    }
}