using UnityEditor.Rendering;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class ToggleAndGlitchPostProcessing : MonoBehaviour
{
    public Volume globalVolume;

    // References to effects
    private ChromaticAberration chromaticAberration;
    private FilmGrain filmGrain;

    // Glitch control variables
    private float glitchTimer = 0f;
    public float glitchIntervalMin = 1f;   // Time between glitches
    public float glitchIntervalMax = 4f;
    public float glitchDuration = 0.75f;    // How long the visual spike lasts
    public float maxGlitchIntensity = 0.8f;

    // Public state for E-key toggle
    public bool isPostProcessingEnabled = false;

    [Header("Light Control")]
    public Light2D light2D;
    public FlashlightController flashlightController;
    public float standardInensity = 0.02f;
    public float newInensity = 0.1f;
    private bool soundMode = false;

    void Start()
    {
        if (globalVolume == null)
        {
            Debug.LogError("Global Volume not assigned.");
            enabled = false;
            return;
        }

        // Get the override components
        globalVolume.profile.TryGet(out chromaticAberration);
        globalVolume.profile.TryGet(out filmGrain);

        // Ensure overrides are enabled so the script can control them
        chromaticAberration.intensity.overrideState = true;
        filmGrain.intensity.overrideState = true;

        // Set initial state: Disabled and start the glitch timer
        globalVolume.enabled = false;
        glitchTimer = GetNextGlitchTime();
    }

    void Update()
    {
        // Toggle the entire effect ON/OFF with 'E'
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            ToggleEffect();
            ToggleLight();
            soundMode = !soundMode;
        }
        if (soundMode)
        {
            flashlightController.isOn = false;
            flashlightController.flashlight.enabled = flashlightController.isOn;
        }

        // Only run the glitch logic if the overall post-processing is enabled
        if (isPostProcessingEnabled)
        {
            HandleGlitch();
        }
    }

    // --- Toggle Logic (from previous script) ---
    public void ToggleEffect()
    {
        isPostProcessingEnabled = !isPostProcessingEnabled;
        globalVolume.enabled = isPostProcessingEnabled;

        // When disabled, reset all dynamic values to a clean state
        if (!isPostProcessingEnabled)
        {
            chromaticAberration.intensity.value = 0f;
            filmGrain.intensity.value = 0f;
        }
    }

    // --- Glitch Logic ---
    void HandleGlitch()
    {
        glitchTimer -= Time.deltaTime;

        // If the timer hits zero, trigger a glitch spike
        if (glitchTimer <= 0f)
        {
            TriggerGlitchSpike();
            glitchTimer = GetNextGlitchTime();
        }
        else if (glitchTimer < glitchDuration)
        {
            // If the timer is still within the short glitch duration, keep the intensity high
            // We use a normalized time (0 to 1) to fade out the effect quickly
            float t = glitchTimer / glitchDuration;

            // Set Chromatic Aberration high for channel split
            chromaticAberration.intensity.value = t * maxGlitchIntensity;

            // Set Film Grain high for static noise
            filmGrain.intensity.value = t * 1f;
        }
        else
        {
            // Outside of the glitch spike, keep the values low (for a persistent subtle nausea/glitch)
            chromaticAberration.intensity.value = 0.05f; // Subtle continuous effect
            filmGrain.intensity.value = 0f;
        }
    }

    void TriggerGlitchSpike()
    {
        // Immediately spike the values when a glitch starts
        chromaticAberration.intensity.value = maxGlitchIntensity;
        filmGrain.intensity.value = 1f;
    }

    float GetNextGlitchTime()
    {
        // Get a new random interval for the next glitch, plus the duration of the spike
        return Random.Range(glitchIntervalMin, glitchIntervalMax) + glitchDuration;
    }


    void ToggleLight()
    {
        if (light2D.intensity == standardInensity)
        {
            light2D.intensity = newInensity;
        } else
        {
            light2D.intensity = standardInensity;
        }
    }

    public bool ReturnMode()
    {
        return soundMode;
    }
}