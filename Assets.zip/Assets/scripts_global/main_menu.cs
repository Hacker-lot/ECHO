using UnityEngine;
using UnityEngine.SceneManagement; // CRITICAL: This allows us to use SceneManager.LoadScene

public class MenuController : MonoBehaviour
{
    [Tooltip("The exact name of your main game scene (e.g., 'GameScene' or 'Level1'). MUST match the name in Build Settings.")]
    public string gameSceneName = "GameScene";

    // --- MUST BE PUBLIC AND TAKE NO PARAMETERS (void) ---
    /// <summary>
    /// Loads the main game scene. Assign this to your "Start Game" button OnClick event.
    /// </summary>
    public void StartGame()
    {
        // 1. Check if the scene name is set
        if (string.IsNullOrEmpty(gameSceneName))
        {
            Debug.LogError("MenuController: Game Scene Name is not set! Cannot load scene.");
            return;
        }

        // 2. Load the scene
        Debug.Log($"Loading game scene: {gameSceneName}");
        SceneManager.LoadScene(gameSceneName);
    }

    // --- MUST BE PUBLIC AND TAKE NO PARAMETERS (void) ---
    /// <summary>
    /// Closes the application. Assign this to your "Quit" button OnClick event.
    /// </summary>
    public void QuitGame()
    {
        Debug.Log("Quitting game...");

        // Quitting works differently in the Editor vs. a built application
#if UNITY_EDITOR
        // Stop playing in the Unity Editor
        UnityEditor.EditorApplication.isPlaying = false;
#else
            // Quit the built application
            Application.Quit();
#endif
    }
}