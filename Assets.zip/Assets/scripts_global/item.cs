using UnityEngine;

namespace Economy
{
    [CreateAssetMenu(fileName = "New Item", menuName = "Economy/Item")]
    public class Item : ScriptableObject
    {
        public string itemName;
        [TextArea(3, 5)]
        public string description;
        public Sprite icon;
        public int price;
        public int sellPrice;

        public bool canBuy = true;
        public bool canSell = true;
    }
}