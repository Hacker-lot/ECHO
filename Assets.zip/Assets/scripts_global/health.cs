using UnityEngine;
using System; // Required for Action delegate

/// <summary>
/// Core component for managing health, taking damage, and signaling death.
/// </summary>
public class HealthSystem : MonoBehaviour
{
    [Header("Health Settings")]
    public float maxHealth = 100f;
    [SerializeField] // Show in Inspector, but private access
    private float currentHealth;

    // --- EVENTS (ACTIONS) ---
    // Event triggered when damage is taken (passes the amount of damage taken)
    public event Action<float> OnDamageTaken;

    // Event triggered when health drops to zero or below (FIX FOR CS1061 ERROR)
    public event Action OnDeath;

    void Awake()
    {
        currentHealth = maxHealth;
    }

    /// <summary>
    /// Reduces health and checks for death.
    /// </summary>
    public void TakeDamage(float damageAmount)
    {
        if (currentHealth <= 0) return;

        currentHealth -= damageAmount;

        // 1. Trigger Damage Event
        OnDamageTaken?.Invoke(damageAmount);

        // 2. Check for Death
        if (currentHealth <= 0)
        {
            currentHealth = 0;
            Die();
        }
    }

    /// <summary>
    /// Resets health to max (used for respawn).
    /// </summary>
    public void ResetHealth()
    {
        currentHealth = maxHealth;
        Debug.Log($"{gameObject.name} health reset to {maxHealth}.");
    }

    /// <summary>
    /// Handles the death sequence.
    /// </summary>
    private void Die()
    {
        Debug.Log($"{gameObject.name} has died.");

        // Trigger Death Event (FIX FOR CS1061 ERROR)
        OnDeath?.Invoke();
    }
}