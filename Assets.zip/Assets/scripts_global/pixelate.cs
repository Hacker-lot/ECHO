// PixelizePass.cs (Simplified Example)
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class PixelizePass : ScriptableRenderPass
{
    private RenderTargetIdentifier source;
    private int pixelHeight = 90; // The target low resolution height
    private Material blitMaterial; // Optional: If you need a special shader
    private RenderTargetHandle tempTarget;

    public PixelizePass(Material material)
    {
        blitMaterial = material;
        tempTarget.Init("_PixelizationTexture");
        renderPassEvent = RenderPassEvent.BeforeRenderingPostProcessing;
    }

    public void Setup(RenderTargetIdentifier source, int height)
    {
        this.source = source;
        this.pixelHeight = height;
    }

    public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
    {
        // Calculate the corresponding low width based on the camera aspect ratio
        float aspectRatio = (float)Screen.width / Screen.height;
        int pixelWidth = Mathf.RoundToInt(pixelHeight * aspectRatio);

        // Define the tiny target texture
        RenderTextureDescriptor desc = new RenderTextureDescriptor(pixelWidth, pixelHeight);

        // Get the command buffer to allocate the temporary target texture
        cmd.GetTemporaryRT(tempTarget.id, desc, FilterMode.Point);
    }

    public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
    {
        if (!renderingData.cameraData.postProcessEnabled) return;

        CommandBuffer cmd = CommandBufferPool.Get("Pixelize Effect");

        // 1. Blit the high-res camera output TO the tiny temp target.
        // This is where the downscaling happens.
        Blit(cmd, source, tempTarget.Identifier());

        // 2. Blit the tiny temp target BACK TO the camera output.
        // This is where the upscaling (pixelation) happens.
        Blit(cmd, tempTarget.Identifier(), source);

        context.ExecuteCommandBuffer(cmd);
        CommandBufferPool.Release(cmd);
    }

    public override void OnCameraCleanup(CommandBuffer cmd)
    {
        // Release the temporary target texture
        cmd.ReleaseTemporaryRT(tempTarget.id);
    }
}