﻿using UnityEngine;
using UnityEngine.UI; // For Image and Text
using TMPro;      // For TextMeshPro (recommended for UI text)
using UnityEngine.EventSystems; // NEW: For IBeginDragHandler, IDropHandler, etc.
using Economy;

// Implement the necessary drag and drop interfaces
public class InventorySlot : MonoBehaviour,
    IBeginDragHandler, IDragHandler, IEndDragHandler, IDropHandler, IPointerClickHandler
{
    // Assign these UI components in the Inspector
    public Image icon;
    public TextMeshProUGUI countText;
    public GameObject countPanel;

    // MODIFIED: Made properties public/private for access by other scripts
    [HideInInspector] public int slotIndex = -1; // NEW: Position index in the Inventory list
    [SerializeField] public Item currentItem;    // Public for inspection/access
    [SerializeField] public int currentCount = 0; // Public for inspection/access
    public bool allowDrag = true;
    public bool allowDrop = true;

    // NEW: References for drag/drop
    private Inventory playerInventory;
    private static GameObject dragIcon;
    private static InventorySlot originalSlot; // Tracks which slot started the drag
    public static bool IsDragging { get; private set; }

    // 🟢 NEW: Reference to the Shop Manager
    private ShopManager shopManager;

    void Start()
    {
        playerInventory = FindObjectOfType<Inventory>();
        if (playerInventory == null)
        {
            Debug.LogError("InventorySlot cannot find Inventory component.");
        }

        // 🟢 NEW: Get the ShopManager reference
        shopManager = FindObjectOfType<ShopManager>();
        if (shopManager == null)
        {
            Debug.LogWarning("InventorySlot cannot find ShopManager component. Selling functionality will be disabled.");
        }
    }

    /// <summary>
    /// Updates the slot's visual representation.
    /// </summary>
    public void UpdateSlot(Item item, int count)
    {
        currentItem = item;
        currentCount = count;

        if (item != null)
        {
            // *** Added Null Checks for robustness ***
            if (icon != null)
            {
                icon.sprite = item.icon;
                icon.enabled = true;
            }

            // Fixes to correctly set the count
            if (countText != null) countText.text = count.ToString();
            if (countPanel != null) countPanel.SetActive(count > 1);
        }
        else
        {
            ClearSlot();
        }
    }

    /// <summary>
    /// Clears the visual representation of the slot.
    /// </summary>
    public void ClearSlot()
    {
        currentItem = null;
        currentCount = 0;

        // *** CRITICAL FIX: Adding null checks to prevent NRE if UI elements are unassigned ***
        if (icon != null)
        {
            icon.sprite = null;
            icon.enabled = false;
        }

        if (countText != null) countText.text = string.Empty;
        if (countPanel != null) countPanel.SetActive(false);
    }

    // --- DRAG/DROP IMPLEMENTATION ---

    public void OnBeginDrag(PointerEventData eventData)
    {
        if (!allowDrag || currentItem == null || icon == null) return; // Add check for icon

        IsDragging = true;
        originalSlot = this; // Store the slot the drag began on

        // 1. Create a static image (Drag Icon) to follow the mouse
        dragIcon = new GameObject("DragIcon");
        Image image = dragIcon.AddComponent<Image>();

        // Copy the sprite from the slot icon
        image.sprite = icon.sprite;
        image.SetNativeSize();

        // Set the parent to the Canvas root to ensure it floats on top
        dragIcon.transform.SetParent(transform.root);

        // Disable raycasts so the pointer can hit the slot underneath
        CanvasGroup cg = dragIcon.AddComponent<CanvasGroup>();
        cg.blocksRaycasts = false;

        // 2. Hide the visual of the original slot
        icon.enabled = false;
        if (countPanel != null) countPanel.SetActive(false);
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (dragIcon != null)
        {
            // The drag icon follows the cursor
            dragIcon.transform.position = eventData.position;
            // Mark that actual dragging occurred (mouse moved)
        }
    }

    public bool Dragging()
    {
        return dragIcon != null;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        // 1. Clean up the temporary visual icon
        if (dragIcon != null)
        {
            Destroy(dragIcon);
            dragIcon = null;
        }

        // 2. If the drop was unsuccessful, restore the original slot visual
        if (originalSlot != null)
        {
            // Restore visual of the slot that was dragged, regardless of success
            if (originalSlot.icon != null)
            {
                originalSlot.icon.enabled = (originalSlot.currentItem != null);
            }

            if (originalSlot.countPanel != null)
            {
                originalSlot.countPanel.SetActive(originalSlot.currentCount > 1);
            }

            // Reset drag flag for next interaction
            originalSlot = null;
        }

        IsDragging = false;
    }

    public void OnDrop(PointerEventData eventData)
    {
        if (!allowDrop) return;

        // Check if the object being dropped is another InventorySlot
        InventorySlot droppedOnSlot = this;
        InventorySlot draggedSlot = eventData.pointerDrag.GetComponent<InventorySlot>();

        if (draggedSlot == null || droppedOnSlot == null) return;

        // Prevent dropping a slot onto itself
        if (draggedSlot.slotIndex == droppedOnSlot.slotIndex) return;

        // Perform the swap/move operation in the Inventory data manager
        if (playerInventory != null)
        {
            playerInventory.SwapSlots(draggedSlot.slotIndex, droppedOnSlot.slotIndex);
        }

        // Trigger a full UI refresh to visually represent the swap
        InventoryGridUI gridUI = FindObjectOfType<InventoryGridUI>();
        if (gridUI != null)
        {
            gridUI.UpdateDisplay();
        }
    }

    /// <summary>
    /// Handles click events to sell items or transfer them (existing search logic).
    /// </summary>
    public void OnPointerClick(PointerEventData eventData)
    {
        // Don't handle clicks if this is a search panel or a shop slot
        if (GetComponent<SearchSlotInteraction>() != null) return;
        // You would add a check for your new ShopSlotInteraction here as well

        // Only handle clicks if this slot has an item and is in the inventory
        if (currentItem == null || slotIndex < 0) return;

        // 🟢 SELLING LOGIC: Check if the Merchant's Shop Panel is active. If so, sell the item.
        if (shopManager != null && shopManager.IsShopOpen())
        {
            // The InventSlot has the slotIndex and the ShopManager has the SellItem(int) method.
            shopManager.SellItem(slotIndex);
            return; // Stop processing other click actions if we just sold an item
        }

        // Existing Logic: Check if search panel is open - if so, transfer item to search panel
        SearchUIManager searchUI = FindObjectOfType<SearchUIManager>();
        // ... (The rest of your transfer logic for SearchUIManager would go here)
    }
}