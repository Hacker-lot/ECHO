using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class InventoryGridUI : MonoBehaviour
{
    [Header("UI References")]
    public Transform slotsParent;

    private InventorySlot[] slots;
    private Inventory playerInventory;
    void Awake()
    {
        playerInventory = FindObjectOfType<Inventory>();
        slots = slotsParent.GetComponentsInChildren<InventorySlot>(true);
        gameObject.SetActive(false);
    }

    void Start()
    {
        if (playerInventory == null)
        {
            Debug.LogError("InventoryGridUI cannot find the Inventory script in the scene.");
            return;
        }

        if (slotsParent != null)
        {
            if (slots.Length != playerInventory.maxCapacity)
            {
                Debug.LogWarning($"Inventory UI has {slots.Length} slots, but Inventory capacity is {playerInventory.maxCapacity}. Adjust your slots to match capacity.");
            }

            // NEW: Assign the slot index to each InventorySlot script
            for (int i = 0; i < slots.Length; i++)
            {
                slots[i].slotIndex = i;
            }

        }
        else
        {
            Debug.LogError("slotsParent is not assigned in the Inspector!");
            return;
        }
    }

    /// <summary>
    /// Refreshes the entire grid display using the Inventory's positional data.
    /// </summary>
    public void UpdateDisplay()
    {
        // Iterate over the UI slots and map them to the Inventory's positional data
        for (int i = 0; i < slots.Length; i++)
        {
            if (i < playerInventory.slots.Count)
            {
                // Access the data directly by index
                Inventory.InventorySlotData data = playerInventory.slots[i];

                if (data.item != null)
                {
                    slots[i].UpdateSlot(data.item, data.count);
                }
                else
                {
                    slots[i].ClearSlot();
                }
            }
            else
            {
                // This handles cases where UI has more slots than maxCapacity
                slots[i].ClearSlot();
            }
        }
    }

    /// <summary>
    /// Shows the inventory panel and refreshes display.
    /// </summary>
    public void ShowInventory()
    {
        if (!gameObject.activeSelf)
        {
            gameObject.SetActive(true);
            UpdateDisplay();
        }
    }

    /// <summary>
    /// Hides the inventory panel. Cannot close while dragging.
    /// </summary>
    public void HideInventory()
    {
        if (InventorySlot.IsDragging)
        {
            Debug.Log("Cannot close inventory while dragging an item.");
            return;
        }

        if (gameObject.activeSelf)
        {
            gameObject.SetActive(false);
        }
    }

    /// <summary>
    /// Toggles the inventory panel visibility. Cannot close while dragging.
    /// </summary>
    public void ToggleInventory()
    {
        if (gameObject.activeSelf)
        {
            HideInventory();
        }
        else
        {
            ShowInventory();
        }
    }

    /// <summary>
    /// Returns whether the inventory panel is currently open.
    /// </summary>
    public bool IsOpen()
    {
        return gameObject.activeSelf;
    }
}