using UnityEngine;

/// <summary>
/// Handles player input for combat, combo tracking, and dealing damage.
/// </summary>
public class PlayerCombat : MonoBehaviour
{
    [Header("Combat Settings")]
    [Tooltip("The base damage dealt by a non-combo hit.")]
    public float baseDamage = 10f;
    [Tooltip("The time window (in seconds) to land a combo hit.")]
    public float comboWindow = 0.5f;
    [Tooltip("The damage multiplier applied during a combo.")]
    public float comboMultiplier = 1.2f;
    [Tooltip("The range (radius) for a player attack.")]
    public float attackRange = 1.0f;
    [Tooltip("The layer(s) that the player attack can hit (e.g., 'Monster').")]
    public LayerMask targetLayer;

    private float lastAttackTime = 0f;

    void Update()
    {
        // Check for Left Mouse Button click
        if (Input.GetMouseButtonDown(0))
        {
            PerformAttack();
        }
    }

    void PerformAttack()
    {
        float damageToDeal = baseDamage;
        bool isCombo = (Time.time - lastAttackTime <= comboWindow);

        // 1. Calculate damage based on combo
        if (isCombo)
        {
            damageToDeal *= comboMultiplier;
            Debug.Log($"Combo hit! Dealing {damageToDeal:F2} damage.");
        }
        else
        {
            Debug.Log($"Normal hit. Dealing {damageToDeal:F2} damage.");
        }

        // 2. Track attack time for next combo check
        lastAttackTime = Time.time;

        // 3. Perform a 2D circle overlap to detect targets
        // The attack is centered on the player's current position.
        Collider2D[] hitTargets = Physics2D.OverlapCircleAll(transform.position, attackRange, targetLayer);

        if (hitTargets.Length > 0)
        {
            foreach (Collider2D targetCollider in hitTargets)
            {
                // Try to get the HealthSystem from the hit target
                HealthSystem targetHealth = targetCollider.GetComponent<HealthSystem>();

                if (targetHealth != null)
                {
                    targetHealth.TakeDamage(damageToDeal);
                }
            }
        }
        else
        {
            Debug.Log("Attack missed or no targets in range.");
        }

        // TODO: Add visual/audio feedback for attack here (Animation, swing sound, etc.)
    }

    /// <summary>
    /// Helper to visualize the attack range in the editor.
    /// </summary>
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        // Draw a wire circle to represent the attack radius
        Gizmos.DrawWireSphere(transform.position, attackRange);
    }
}