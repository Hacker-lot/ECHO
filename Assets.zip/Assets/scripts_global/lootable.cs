using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using Economy;
public class Lootable : MonoBehaviour
{
    [System.Serializable]
    public class LootDrop
    {
        public Item item;
        public int minCount = 1;
        public int maxCount = 1;
        [Range(0f, 1f)]
        public float dropChance = 1f;
    }

    public float baseSearchDuration = 2.0f;
    public List<LootDrop> potentialLoot = new List<LootDrop>();

    // �ڲ�״̬
    private bool lootGenerated = false;
    private List<Inventory.InventorySlotData> currentLoot = new List<Inventory.InventorySlotData>();

    public bool IsDepleted => lootGenerated && currentLoot.All(slot => slot.item == null || slot.count <= 0);

    /// <summary>
    /// �����Ƿ��Ѿ����ɹ���Ʒ
    /// </summary>
    public bool HasGeneratedLoot()
    {
        return lootGenerated;
    }

    /// <summary>
    /// ���ص�ǰ����ʣ����Ʒ
    /// </summary>
    public List<Inventory.InventorySlotData> GetCurrentLoot()
    {
        return currentLoot;
    }

    /// <summary>
    /// ����������Ʒ����һ�δ�ʱ����
    /// </summary>
    public List<Inventory.InventorySlotData> GenerateLoot()
    {
        if (lootGenerated)
            return currentLoot;

        currentLoot.Clear();

        foreach (var drop in potentialLoot)
        {
            if (Random.value <= drop.dropChance)
            {
                int count = Random.Range(drop.minCount, drop.maxCount + 1);
                for (int i = 0; i < count; i++)
                {
                    currentLoot.Add(new Inventory.InventorySlotData
                    {
                        item = drop.item,
                        count = 1
                    });
                }
            }
        }

        lootGenerated = true;

        // --- 随机打乱 currentLoot ---
        for (int i = 0; i < currentLoot.Count; i++)
        {
            int j = Random.Range(i, currentLoot.Count); // 从 i 到 Count-1 随机选择
            var temp = currentLoot[i];
            currentLoot[i] = currentLoot[j];
            currentLoot[j] = temp;
        }

        lootGenerated = true;
        Debug.Log("shuffled");
        return currentLoot;
    }

    public void MarkDepleted()
    {
        lootGenerated = true;
        currentLoot.Clear();
    }

    /// <summary>
    /// ���ݵ��伸�ʼ�������ʱ��
    /// </summary>
    public float CalculateSearchDuration()
    {
        if (potentialLoot.Count == 0) return baseSearchDuration;

        float averageChance = 0f;
        foreach (var drop in potentialLoot)
        {
            averageChance += drop.dropChance;
        }
        averageChance /= potentialLoot.Count;

        float difficultyFactor = 1.0f / Mathf.Max(0.1f, averageChance);
        return baseSearchDuration * difficultyFactor;
    }
}
