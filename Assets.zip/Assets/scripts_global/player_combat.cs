using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement; // Needed to reload the scene for a complete reset

/// <summary>
/// Handles player-specific combat feedback (flashing), death, and respawn logic.
/// Requires a HealthSystem component on the same GameObject.
/// </summary>
public class PlayerCombatAndRespawn : MonoBehaviour
{
    [Header("Visual Feedback")]
    public SpriteRenderer spriteRenderer;
    [Tooltip("Color to flash when damage is taken.")]
    public Color damageColor = Color.red;
    [Tooltip("Duration of the red flash (in seconds).")]
    public float flashDuration = 0.15f;
    private Color originalColor;
    private Coroutine flashCoroutine;

    [Header("Respawn Settings")]
    public Vector3 respawnPosition = Vector3.zero;

    private HealthSystem healthSystem;
    private Inventory playerInventory;

    void Start()
    {
        // Get references
        healthSystem = GetComponent<HealthSystem>();
        playerInventory = FindObjectOfType<Inventory>();

        if (healthSystem == null)
        {
            Debug.LogError("PlayerCombatAndRespawn requires a HealthSystem component!");
            return;
        }

        if (spriteRenderer == null)
        {
            spriteRenderer = GetComponent<SpriteRenderer>();
        }

        if (spriteRenderer != null)
        {
            originalColor = spriteRenderer.color;
        }
        else
        {
            Debug.LogWarning("Player SpriteRenderer missing. Damage flash visual will not work.");
        }

        // Subscribe to HealthSystem events
        healthSystem.OnDamageTaken += OnPlayerDamaged;
        healthSystem.OnDeath += OnPlayerDeath;
    }

    private void OnDestroy()
    {
        // Clean up subscriptions
        if (healthSystem != null)
        {
            healthSystem.OnDamageTaken -= OnPlayerDamaged;
            healthSystem.OnDeath -= OnPlayerDeath;
        }
    }

    /// <summary>
    /// Triggered when the player takes damage.
    /// </summary>
    private void OnPlayerDamaged(float damageAmount)
    {
        FlashRed();
    }

    /// <summary>
    /// Triggered when the player's health reaches zero.
    /// </summary>
    private void OnPlayerDeath()
    {
        Debug.Log("Player Died! Starting respawn sequence.");

        // --- REMOVED TIME MANAGER CALLS ---

        // Start the respawn process
        StartCoroutine(RespawnSequence(1.0f)); // 1 second delay before respawn
    }

    /// <summary>
    /// Handles the visual flash effect.
    /// </summary>
    private void FlashRed()
    {
        if (spriteRenderer == null) return;

        // Stop any existing flash to start a new one cleanly
        if (flashCoroutine != null)
        {
            StopCoroutine(flashCoroutine);
            spriteRenderer.color = originalColor;
        }

        flashCoroutine = StartCoroutine(FlashCoroutine());
    }

    /// <summary>
    /// Coroutine to handle the color flash.
    /// </summary>
    private IEnumerator FlashCoroutine()
    {
        spriteRenderer.color = damageColor;
        yield return new WaitForSeconds(flashDuration);
        spriteRenderer.color = originalColor;
        flashCoroutine = null;
    }

    /// <summary>
    /// Coroutine to handle the player respawn sequence.
    /// </summary>
    IEnumerator RespawnSequence(float delay)
    {
        // 1. Wait for a short delay (using standard WaitForSeconds now)
        yield return new WaitForSeconds(delay);

        // 2. Clear Inventory
        ResetInventory();

        // 3. Complete Scene Reset (reloading the scene resets everything)
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    /// <summary>
    /// Clears all items from the player's inventory.
    /// </summary>
    private void ResetInventory()
    {
        if (playerInventory != null)
        {
            // Use the dedicated ClearAllItems() method
            playerInventory.ClearAllItems();
            Debug.Log("Player inventory has been reset.");
        }
    }
}