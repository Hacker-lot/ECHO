﻿using UnityEngine;
using System.Collections;
using UnityEngine.Rendering.Universal;

public class Monster : MonoBehaviour
{
    // --- 状态枚举 ---
    public enum MonsterState
    {
        Patrolling,
        Chasing,
        CheckingSound
    }

    [Header("Combat References")]
    private HealthSystem myHealth; // Monster's own health system
    private HealthSystem playerHealth; // Player's health system

    [Header("Damage Settings")]
    [Tooltip("Damage dealt to the player per tick.")]
    public float damagePerTick = 10f;
    [Tooltip("Interval (in seconds) between damage ticks.")]
    public float damageTickInterval = 1f;
    private float damageTimer = 0f;

    // --- NEW VISUAL DAMAGE FEEDBACK ---
    [Header("Damage Visuals")]
    [Tooltip("Color to flash when damage is taken.")]
    public Color damageColor = Color.red;
    [Tooltip("Duration of the red flash (in seconds).")]
    public float flashDuration = 0.15f;
    private Color originalColor;
    private Coroutine flashCoroutine;

    [Header("Movement Settings")]
    public float patrolSpeed = 2f;          // 巡逻速度
    public float chaseSpeed = 3.5f;        // 追逐玩家速度
    public float minPatrolDistance = 1f;   // 随机巡逻最短距离
    public float maxPatrolDistance = 5f;   // 随机巡逻最长距离
    public float changeDirectionInterval = 2f; // 巡逻改变方向间隔
    public float stopChaseDistance = 1.0f; // 停止追逐的距离

    [Header("Detection Settings")]
    public bool vicious;
    public ToggleAndGlitchPostProcessing toggle;
    public float detectionRadius = 3f;      // 玩家近距离触发追逐
    public float loseAggroDistance = 6f;    // 追逐过程中丢失仇恨距离
    public float flashlightDetectionRadius = 5f; // 手电筒可视范围触发追逐

    [Header("Sound Mode Settings")]
    public float soundModeDetectionRadius = 10f; // 玩家音波范围
    public float soundLoseDistance = 12f;

    [Header("References")]
    public Transform player;
    public FlashlightController flashlight;
    public PlayerSoundWave soundWave; // 玩家发出的声波对象
    public AudioSource chaseAudio;
    public bool isPlayed = false;

    [Header("Animation")]
    public Animator animator; // Animator component reference
    public SpriteRenderer spriteRenderer; // SpriteRenderer reference for flipping

    private Rigidbody2D rb2d;

    private Vector3 patrolTarget;
    private float changeDirTimer = 0f;
    private MonsterState currentState = MonsterState.Patrolling; // 初始状态为巡逻
    private Vector3 previousPosition; // To calculate current speed

    void Start()
    {
        patrolTarget = transform.position;

        // Initialize previous position
        previousPosition = transform.position;

        // --- COMBAT INITIALIZATION ---
        myHealth = GetComponent<HealthSystem>();
        if (player != null)
        {
            playerHealth = player.GetComponent<HealthSystem>();
        }

        if (myHealth == null)
        {
            Debug.LogError("Monster is missing the HealthSystem component!");
            return;
        }

        myHealth.OnDamageTaken += OnMonsterDamaged;

        if (animator == null)
        {
            animator = GetComponent<Animator>();
        }
        if (spriteRenderer == null)
        {
            spriteRenderer = GetComponent<SpriteRenderer>();
        }

        originalColor = spriteRenderer.color;

        // --- PHYSICS FIX ---
        rb2d = GetComponent<Rigidbody2D>();
        if (rb2d != null)
        {
            rb2d.gravityScale = 0f;
            rb2d.isKinematic = true;
        }

        gameObject.tag = "Monster";
    }

    private void OnDestroy()
    {
        if (myHealth != null)
        {
            myHealth.OnDamageTaken -= OnMonsterDamaged;
        }
    }

    private void OnMonsterDamaged(float damageAmount)
    {
        FlashRed();
    }

    private void FlashRed()
    {
        if (spriteRenderer == null) return;

        if (flashCoroutine != null)
        {
            StopCoroutine(flashCoroutine);
            spriteRenderer.color = originalColor;
        }

        flashCoroutine = StartCoroutine(FlashCoroutine());
    }

    private IEnumerator FlashCoroutine()
    {
        spriteRenderer.color = damageColor;
        yield return new WaitForSeconds(flashDuration);
        spriteRenderer.color = originalColor;
        flashCoroutine = null;
    }

    void Update()
    {
        if (Time.timeScale == 0f) return;

        if (player == null) return;

        float distanceToPlayer = Vector3.Distance(transform.position, player.position);
        bool playerNormalMode = !toggle.ReturnMode();

        switch (currentState)
        {
            case MonsterState.Patrolling:
                HandlePatrolling();
                break;

            case MonsterState.Chasing:
                HandleChasing(distanceToPlayer);
                break;

            case MonsterState.CheckingSound:
                HandleCheckingSound();
                break;
        }

        // 根据模式切换状态
        if (playerNormalMode)
        {
            bool inFlashlight = flashlight != null && flashlight.IsOn && IsInFlashlightRange(flashlight.flashlight, transform.position);
            if (inFlashlight || distanceToPlayer <= detectionRadius)
            {
                TransitionToState(MonsterState.Chasing);
            }
            else if (currentState == MonsterState.Chasing && distanceToPlayer > loseAggroDistance)
            {
                TransitionToState(MonsterState.Patrolling);
            }
        }
        else // Sound Mode
        {
            if (soundWave != null && soundWave.HasNewSound())
            {
                Debug.Log("Sound emitted");
                Vector3 soundPosition = soundWave.GetSoundPosition();
                float distanceToSoundWave = Vector3.Distance(transform.position, soundPosition);

                if (distanceToSoundWave <= soundModeDetectionRadius)
                {
                    TransitionToState(MonsterState.CheckingSound);
                }
                else if (Vector3.Distance(transform.position, player.position) <= detectionRadius)
                {
                    TransitionToState(MonsterState.Chasing);
                }
            }
        }

        UpdateAnimation();
    }

    private void TransitionToState(MonsterState newState)
    {
        currentState = newState;
        switch (currentState)
        {
            case MonsterState.Patrolling:
                break;

            case MonsterState.Chasing:
                StartChase(player.position);
                break;

            case MonsterState.CheckingSound:
                break;
        }
    }

    void HandlePatrolling()
    {
        changeDirTimer -= Time.deltaTime;
        if (changeDirTimer <= 0f || Vector3.Distance(transform.position, patrolTarget) < 0.1f)
        {
            patrolTarget = GenerateRandomPatrolTarget();
            changeDirTimer = changeDirectionInterval;
        }
        MoveTowards(patrolTarget, patrolSpeed);
    }

    void HandleChasing(float distanceToPlayer)
    {
        if (distanceToPlayer > stopChaseDistance)
        {
            MoveTowards(player.position, chaseSpeed);
            damageTimer = 0f;
        }
        else
        {
            MoveTowards(transform.position, 0f);
            DamagePlayerOnContact();
        }
    }

    void HandleCheckingSound()
    {
        Vector3 soundPosition = soundWave.GetSoundPosition();
        float distanceToSoundWave = Vector3.Distance(transform.position, soundPosition);

        if (distanceToSoundWave <= 0.1f)
        {
            TransitionToState(MonsterState.Patrolling);
        }
        else if (Vector3.Distance(transform.position, player.position) <= detectionRadius)
        {
            TransitionToState(MonsterState.Chasing);
        }
        else
        {
            MoveTowards(soundPosition, patrolSpeed);
        }
    }

    void DamagePlayerOnContact()
    {
        if (playerHealth == null) return;

        damageTimer += Time.deltaTime;

        if (damageTimer >= damageTickInterval)
        {
            playerHealth.TakeDamage(damagePerTick);
            damageTimer = 0f;
        }
    }

    void UpdateAnimation()
    {
        if (animator == null || Time.deltaTime == 0)
        {
            return;
        }

        Vector3 displacement = transform.position - previousPosition;
        float distanceMoved = new Vector2(displacement.x, displacement.y).magnitude;
        float currentSpeed = distanceMoved / Time.deltaTime;

        animator.SetFloat("Speed", currentSpeed);

        if (spriteRenderer != null && currentSpeed > 0.01f)
        {
            spriteRenderer.flipX = displacement.x < 0;
        }

        previousPosition = transform.position;
    }

    Vector3 GenerateRandomPatrolTarget()
    {
        Vector2 randomDir = Random.insideUnitCircle.normalized;
        float randomDistance = Random.Range(minPatrolDistance, maxPatrolDistance);
        return transform.position + new Vector3(randomDir.x, randomDir.y, 0f) * randomDistance;
    }

    void MoveTowards(Vector3 target, float speed)
    {
        if (speed <= 0f) return;
        transform.position = Vector3.MoveTowards(transform.position, target, speed * Time.deltaTime);
    }

    void StartChase(Vector3 targetPos)
    {
        if (chaseAudio != null && !chaseAudio.isPlaying && !isPlayed)
        {
            chaseAudio.Play();
            isPlayed = true;
        }
    }

    void StopChase()
    {
        isPlayed = false;
    }

    private bool IsInFlashlightRange(Light2D flashlight, Vector3 monsterPosition)
    {
        Vector2 lightDirection = flashlight.transform.up;
        float lightRange = flashlight.pointLightOuterRadius;
        Vector2 toMonster = monsterPosition - flashlight.transform.position;
        float distanceToMonster = toMonster.magnitude;

        if (distanceToMonster > lightRange) return false;

        float angleToMonster = Vector2.Angle(lightDirection, toMonster);
        return angleToMonster <= flashlight.pointLightOuterAngle;
    }
}
